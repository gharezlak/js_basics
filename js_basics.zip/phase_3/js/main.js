var circle1 = document.getElementById("circle1");
var circle2 = document.getElementById("circle2");
var circle3 = document.getElementById("circle3");

circle1.addEventListener("click", function(){
	document.getElementsByTagName('body')[0].style.backgroundColor = 'red';
});

circle2.addEventListener("click", function(){
	document.getElementsByTagName('body')[0].style.backgroundColor = 'yellow';
});

circle3.addEventListener("click", function(){
	document.getElementsByTagName('body')[0].style.backgroundColor = 'green';
});